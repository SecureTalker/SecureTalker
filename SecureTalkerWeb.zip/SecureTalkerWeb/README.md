# SecureTalker Web

Ein einfacher 1-zu-1 verschlüsselter Webchat. Alles läuft lokal im Browser.

## Features

- AES-verschlüsselte Nachrichten
- Kein Server, keine Speicherung
- Nur JavaScript im Browser
- Ideal für Safari/Web-App

## Nutzung

1. Lade das Projekt auf GitHub hoch
2. Aktiviere GitHub Pages in den Repo-Einstellungen
3. Rufe es auf unter `https://<deinname>.github.io/securetalker/`
